import unittest

import numpy as np

from heat2d.grid import create_grid
from heat2d.solver import solve


class SolverTests(unittest.TestCase):
    def test_uniform_boundary_temperature_remains_constant(self):
        X, _, dx, dy, dt = create_grid(1.0, 21, 1.0, 21, 0.01)
        initial = np.full(X.shape, 20.0)
        times = np.linspace(0.0, 0.2, 5)

        history = solve(initial, times, 0.01, dt, dx, dy)

        self.assertEqual(len(history), len(times))
        for temperature in history:
            np.testing.assert_allclose(temperature, 20.0)

    def test_solver_does_not_modify_initial_array(self):
        X, Y, dx, dy, dt = create_grid(1.0, 21, 1.0, 21, 0.01)
        initial = 20.0 + np.sin(np.pi * X) * np.sin(np.pi * Y)
        original = initial.copy()

        solve(initial, np.array([0.0, 0.1]), 0.01, dt, dx, dy)

        np.testing.assert_array_equal(initial, original)

    def test_sine_mode_agrees_with_analytical_solution(self):
        x_length = 2.0
        y_length = 1.0
        alpha = 0.01
        final_time = 0.2
        X, Y, dx, dy, dt = create_grid(
            x_length,
            81,
            y_length,
            41,
            alpha,
        )
        initial = (
            20.0
            + np.sin(np.pi * X / x_length)
            * np.sin(np.pi * Y / y_length)
        )

        result = solve(
            initial,
            np.array([0.0, final_time]),
            alpha,
            dt,
            dx,
            dy,
        )[-1]
        exact = (
            20.0
            + np.exp(
                -alpha
                * np.pi**2
                * (1 / x_length**2 + 1 / y_length**2)
                * final_time
            )
            * np.sin(np.pi * X / x_length)
            * np.sin(np.pi * Y / y_length)
        )

        self.assertLess(np.max(np.abs(result - exact)), 1e-4)

    def test_unstable_time_step_is_rejected(self):
        temperature = np.full((5, 5), 20.0)

        with self.assertRaisesRegex(ValueError, "稳定性条件"):
            solve(
                temperature,
                np.array([0.0, 2.0]),
                alpha=0.01,
                dt=2.0,
                dx=0.25,
                dy=0.25,
            )


if __name__ == "__main__":
    unittest.main()
