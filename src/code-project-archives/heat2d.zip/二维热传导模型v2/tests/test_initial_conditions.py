import unittest

import numpy as np

from heat2d.boundary import boundary
from heat2d.grid import create_grid
from heat2d.initial_conditions import initial_temperature


class BoundaryTests(unittest.TestCase):
    def test_boundary_sets_all_four_edges_to_twenty(self):
        temperature = np.zeros((7, 9), dtype=float)

        result = boundary(temperature)

        self.assertIs(result, temperature)
        np.testing.assert_allclose(result[0, :], 20.0)
        np.testing.assert_allclose(result[-1, :], 20.0)
        np.testing.assert_allclose(result[:, 0], 20.0)
        np.testing.assert_allclose(result[:, -1], 20.0)
        np.testing.assert_allclose(result[1:-1, 1:-1], 0.0)


class InitialTemperatureTests(unittest.TestCase):
    def test_two_gaussian_peaks_are_at_expected_locations(self):
        X, Y, _, _, _ = create_grid(1.0, 101, 1.0, 101, 0.01)

        temperature = initial_temperature(0.12, X, Y)

        expected_peak = 300.0 + 280.0 * np.exp(
            -(0.4**2) / (2 * 0.12**2)
        )
        self.assertAlmostEqual(temperature[50, 30], expected_peak)
        self.assertAlmostEqual(temperature[50, 70], expected_peak)
        self.assertLess(temperature[50, 50], temperature[50, 30])

    def test_initial_temperature_is_symmetric_and_respects_boundary(self):
        X, Y, _, _, _ = create_grid(2.0, 21, 1.0, 11, 0.01)

        temperature = initial_temperature(0.12, X, Y)

        np.testing.assert_allclose(temperature, temperature[::-1, ::-1])
        np.testing.assert_allclose(temperature[0, :], 20.0)
        np.testing.assert_allclose(temperature[-1, :], 20.0)
        np.testing.assert_allclose(temperature[:, 0], 20.0)
        np.testing.assert_allclose(temperature[:, -1], 20.0)


if __name__ == "__main__":
    unittest.main()
