import io
import unittest
from unittest.mock import patch

from heat2d.config import SimulationConfig, set_config, user_input


class UserInputTests(unittest.TestCase):
    def test_invalid_value_is_retried(self):
        with (
            patch("builtins.input", side_effect=["abc", "-1", "2.5"]),
            patch("sys.stdout", new_callable=io.StringIO),
        ):
            result = user_input(
                name="测试参数",
                default=1.0,
                dtype=float,
                validator=lambda value: value > 0,
                error_message="必须大于0",
            )

        self.assertEqual(result, 2.5)


class SimulationConfigTests(unittest.TestCase):
    def test_empty_inputs_return_default_config(self):
        with (
            patch("builtins.input", side_effect=[""] * 8),
            patch("sys.stdout", new_callable=io.StringIO),
        ):
            config = set_config()

        self.assertEqual(config, SimulationConfig())

    def test_custom_inputs_are_converted_to_expected_types(self):
        values = ["2", "3", "51", "61", "0.02", "0.2", "4", "20"]

        with (
            patch("builtins.input", side_effect=values),
            patch("sys.stdout", new_callable=io.StringIO),
        ):
            config = set_config()

        self.assertEqual(
            config,
            SimulationConfig(
                x_length=2.0,
                y_length=3.0,
                nx=51,
                ny=61,
                alpha=0.02,
                sigma=0.2,
                time=4.0,
                frames=20,
            ),
        )

    def test_grid_counts_below_three_are_rejected(self):
        values = ["", "", "1", "101", "2", "101", "", "", "", ""]

        with (
            patch("builtins.input", side_effect=values),
            patch("sys.stdout", new_callable=io.StringIO),
        ):
            config = set_config()

        self.assertEqual(config.nx, 101)
        self.assertEqual(config.ny, 101)


if __name__ == "__main__":
    unittest.main()
