import unittest

import numpy as np

from heat2d.grid import create_grid


class GridTests(unittest.TestCase):
    def test_rectangular_grid_has_expected_shape_and_spacing(self):
        X, Y, dx, dy, _ = create_grid(
            x_length=2.0,
            nx=21,
            y_length=1.0,
            ny=11,
            alpha=0.01,
        )

        self.assertEqual(X.shape, (11, 21))
        self.assertEqual(Y.shape, (11, 21))
        self.assertAlmostEqual(dx, 0.1)
        self.assertAlmostEqual(dy, 0.1)
        self.assertAlmostEqual(X.min(), 0.0)
        self.assertAlmostEqual(X.max(), 2.0)
        self.assertAlmostEqual(Y.min(), 0.0)
        self.assertAlmostEqual(Y.max(), 1.0)

    def test_generated_time_step_has_stability_margin(self):
        alpha = 0.01
        _, _, dx, dy, dt = create_grid(1.0, 51, 1.0, 51, alpha)

        rx = alpha * dt / dx**2
        ry = alpha * dt / dy**2

        self.assertAlmostEqual(rx + ry, 0.4)
        self.assertLess(rx + ry, 0.5)

    def test_mesh_coordinates_increase_along_expected_axes(self):
        X, Y, _, _, _ = create_grid(2.0, 5, 3.0, 7, 0.01)

        np.testing.assert_allclose(X[0], np.linspace(0.0, 2.0, 5))
        np.testing.assert_allclose(Y[:, 0], np.linspace(0.0, 3.0, 7))


if __name__ == "__main__":
    unittest.main()
