import numpy as np

from .boundary import boundary


def initial_temperature(sigma, X, Y):
    x_min = X.min()
    x_length = X.max() - x_min
    y_center = (Y.min() + Y.max()) / 2

    left_center = x_min + 0.3 * x_length
    right_center = x_min + 0.7 * x_length

    left_hot_spot = 280 * np.exp(
        -(
            (X - left_center) ** 2
            + (Y - y_center) ** 2
        )
        / (2 * sigma**2)
    )
    right_hot_spot = 280 * np.exp(
        -(
            (X - right_center) ** 2
            + (Y - y_center) ** 2
        )
        / (2 * sigma**2)
    )

    temperature = 20 + left_hot_spot + right_hot_spot

    boundary(temperature)

    return temperature
