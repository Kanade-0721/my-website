from dataclasses import dataclass


@dataclass
class SimulationConfig:
    x_length: float = 1.0
    y_length: float = 1.0
    nx: int = 121
    ny: int = 121
    alpha: float = 0.01
    sigma: float = 0.12
    time: float = 2.0
    frames: int = 100


def user_input(
    name,
    default,
    dtype,
    validator=None,
    error_message="value error",
):
    while True:
        value = input(f"请输入{name},默认值为{default}:").strip()

        if value == "":
            return default

        try:
            value = dtype(value)
        except ValueError:
            print("请输入有效值")
            continue

        if validator is not None and not validator(value):
            print(error_message)
            continue

        return value


def set_config():
    default = SimulationConfig()

    print("二维热传导模型参数设置")
    print("直接按Enter将使用默认值")

    x_length = user_input(
        name="平板长度",
        default=default.x_length,
        dtype=float,
        validator=lambda value: value > 0,
        error_message="长度必须大于0",
    )

    y_length = user_input(
        name="平板宽度",
        default=default.y_length,
        dtype=float,
        validator=lambda value: value > 0,
        error_message="宽度必须大于0",
    )

    nx = user_input(
        name="x方向网格格数",
        default=default.nx,
        dtype=int,
        validator=lambda value: value > 2,
        error_message="网格格数必须大于2",
    )

    ny = user_input(
        name="y方向网格格数",
        default=default.ny,
        dtype=int,
        validator=lambda value: value > 2,
        error_message="网格格数必须大于2",
    )

    alpha = user_input(
        name="alpha的值",
        default=default.alpha,
        dtype=float,
        validator=lambda value: value > 0,
        error_message="alpha的值必须大于0",
    )

    sigma = user_input(
        name="sigma的值",
        default=default.sigma,
        dtype=float,
        validator=lambda value: value > 0,
        error_message="sigma的值必须大于0",
    )

    time = user_input(
        name="运行时间",
        default=default.time,
        dtype=float,
        validator=lambda value: value > 0,
        error_message="运行时间必须大于0",
    )

    frames = user_input(
        name="帧数",
        default=default.frames,
        dtype=int,
        validator=lambda value: value > 0,
        error_message="帧数必须大于0",
    )

    return SimulationConfig(
        x_length=x_length,
        y_length=y_length,
        nx=nx,
        ny=ny,
        alpha=alpha,
        sigma=sigma,
        time=time,
        frames=frames,
    )
