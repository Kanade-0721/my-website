# 二维泊松方程求解器

这是一个使用五点有限差分格式求解二维泊松方程的 Python 项目。目前已经实现 SciPy 稀疏矩阵直接法，后续可在统一的求解器目录中加入 Jacobi、Gauss–Seidel 和 SOR 方法。

## 数学模型

项目求解矩形区域上的边值问题：

\[
-\nabla^2T=q(x,y),
\qquad T\big|_{\partial\Omega}=0.
\]

默认区域为 \([0,1]\times[0,1]\)，源项为中心位于 \((0.5,0.5)\) 的高斯函数：

\[
q(x,y)=1000\exp\left(
-\frac{(x-0.5)^2+(y-0.5)^2}{2(0.1)^2}
\right).
\]

这里的 `1000` 是数学源项的峰值，不是初始温度。若要解释为真实导热问题，还需要引入导热系数、热源单位和物理边界温度。

## 项目结构

```text
.
├── docs/
│   └── problem.md                 # 完整问题与后续实验要求
├── src/
│   └── poisson_solver/
│       ├── __init__.py            # 公共 API
│       ├── __main__.py            # python -m 入口
│       ├── app.py                 # 默认算例流程
│       ├── boundary.py            # 边界条件
│       ├── config.py              # 模拟参数
│       ├── mesh.py                # 均匀网格
│       ├── residual.py            # 相对残差
│       ├── source.py              # 高斯源项
│       ├── visualization.py       # 温度场绘图
│       └── solvers/
│           ├── __init__.py
│           └── direct.py          # 稀疏矩阵直接法
├── .gitignore
├── pyproject.toml                 # 项目元数据和依赖
└── README.md
```

## 环境要求

- Python 3.10 或更高版本
- NumPy
- SciPy
- Matplotlib

依赖已经统一声明在 `pyproject.toml` 中。

## 安装

建议先创建虚拟环境。在 PowerShell 中执行：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e .
```

`-e` 表示以可编辑模式安装，修改 `src/poisson_solver` 中的源码后不需要重新安装。

## 运行

如果只想直接运行项目，不需要先安装：

```powershell
python main.py
```

根目录的 `main.py` 是启动器，实际程序仍位于 `src/poisson_solver`。

如果已经使用可编辑模式安装，则可以使用模块入口：

```powershell
python -m poisson_solver
```

也可以使用项目命令：

```powershell
poisson-solver
```

程序会打印中心温度和相对残差，并显示温度场。默认 `101×101` 网格的中心温度应约为：

```text
16.278197
```

直接求解器的相对残差通常应接近机器精度。

## 修改参数

默认参数集中在 `src/poisson_solver/config.py`：

```python
SimulationConfig(
    x_length=1.0,
    y_length=1.0,
    nx=101,
    ny=101,
    source_amplitude=1000.0,
    source_sigma=0.1,
)
```

其中 `nx` 和 `ny` 包含边界节点，因此内部未知量数量为 `(nx - 2) × (ny - 2)`。

## 在代码中调用

```python
from poisson_solver import create_mesh, gaussian_source, solve_direct

x_grid, y_grid, dx, dy = create_mesh(1.0, 1.0, 101, 101)
source = gaussian_source(
    x_grid,
    y_grid,
    x_center=0.5,
    y_center=0.5,
    sigma=0.1,
    amplitude=1000.0,
)
temperature, residual = solve_direct(source, dx, dy)

print(temperature[50, 50])
print(residual)
```

## 数值方法

对内部节点使用五点差分格式：

\[
\left(\frac{2}{\Delta x^2}+\frac{2}{\Delta y^2}\right)T_{i,j}
-\frac{T_{i-1,j}+T_{i+1,j}}{\Delta x^2}
-\frac{T_{i,j-1}+T_{i,j+1}}{\Delta y^2}
=q_{i,j}.
\]

离散后得到稀疏线性方程组 \(A\mathbf T=\mathbf b\)，当前使用 `scipy.sparse.linalg.spsolve` 求解，并计算相对无穷范数残差：

\[
\frac{\|A\mathbf T-\mathbf b\|_\infty}{\|\mathbf b\|_\infty}.
\]

## 后续计划

- 实现 Jacobi、Gauss–Seidel 和 SOR 迭代法。
- 记录迭代次数、运行时间和残差历史。
- 增加解析解验证和网格二阶收敛测试。
- 增加源项、等值线、中心截面和收敛曲线可视化。

完整的数值实验要求见 [`docs/problem.md`](docs/problem.md)。
