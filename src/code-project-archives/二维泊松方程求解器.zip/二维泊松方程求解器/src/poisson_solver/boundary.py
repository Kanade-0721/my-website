import numpy as np


def apply_zero_dirichlet_boundary(field: np.ndarray) -> np.ndarray:
    """Set all four edges of a two-dimensional field to zero in place."""

    if field.ndim != 2:
        raise ValueError("field must be a two-dimensional array.")

    field[:, 0] = 0.0
    field[:, -1] = 0.0
    field[0, :] = 0.0
    field[-1, :] = 0.0
    return field
