import numpy as np
from numpy.typing import NDArray


def create_mesh(
    x_length: float,
    y_length: float,
    nx: int,
    ny: int,
) -> tuple[NDArray[np.float64], NDArray[np.float64], float, float]:
    """Create a uniform rectangular mesh and return ``X, Y, dx, dy``."""

    x = np.linspace(0.0, x_length, nx)
    y = np.linspace(0.0, y_length, ny)
    x_grid, y_grid = np.meshgrid(x, y)
    dx = float(x[1] - x[0])
    dy = float(y[1] - y[0])
    return x_grid, y_grid, dx, dy
