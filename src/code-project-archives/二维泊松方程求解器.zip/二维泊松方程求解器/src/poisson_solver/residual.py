import numpy as np
from numpy.typing import NDArray
from scipy.sparse import sparray, spmatrix


def relative_residual(
    matrix: spmatrix | sparray,
    solution: NDArray[np.float64],
    right_hand_side: NDArray[np.float64],
) -> float:
    """Return ``||A x - b||_inf / ||b||_inf``."""

    residual = matrix @ solution - right_hand_side
    denominator = max(np.linalg.norm(right_hand_side, ord=np.inf), 1e-30)
    return float(np.linalg.norm(residual, ord=np.inf) / denominator)
