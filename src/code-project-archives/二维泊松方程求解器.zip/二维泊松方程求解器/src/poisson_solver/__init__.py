"""Two-dimensional Poisson equation solver."""

from .config import SimulationConfig
from .mesh import create_mesh
from .solvers.direct import assemble_poisson_system, solve_direct
from .source import gaussian_source

__all__ = [
    "SimulationConfig",
    "assemble_poisson_system",
    "create_mesh",
    "gaussian_source",
    "solve_direct",
]
