import numpy as np
from numpy.typing import NDArray

from .boundary import apply_zero_dirichlet_boundary


def gaussian_source(
    x_grid: NDArray[np.float64],
    y_grid: NDArray[np.float64],
    x_center: float,
    y_center: float,
    sigma: float,
    amplitude: float = 1000.0,
) -> NDArray[np.float64]:
    """Return a Gaussian source distribution on the supplied mesh."""

    if x_grid.shape != y_grid.shape:
        raise ValueError("x_grid and y_grid must have the same shape.")
    if sigma <= 0:
        raise ValueError("sigma must be positive.")

    radius_squared = (x_grid - x_center) ** 2 + (y_grid - y_center) ** 2
    source = amplitude * np.exp(-radius_squared / (2.0 * sigma**2))
    return apply_zero_dirichlet_boundary(source)
