from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SimulationConfig:
    """Parameters for the default Poisson problem."""

    x_length: float = 1.0
    y_length: float = 1.0
    nx: int = 101
    ny: int = 101
    source_amplitude: float = 1000.0
    source_sigma: float = 0.1

    def __post_init__(self) -> None:
        if self.x_length <= 0 or self.y_length <= 0:
            raise ValueError("Domain lengths must be positive.")
        if self.nx < 3 or self.ny < 3:
            raise ValueError("Each grid direction must contain at least 3 points.")
        if self.source_sigma <= 0:
            raise ValueError("source_sigma must be positive.")
