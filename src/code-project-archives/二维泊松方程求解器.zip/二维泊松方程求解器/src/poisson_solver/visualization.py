import matplotlib.pyplot as plt
import numpy as np
from numpy.typing import NDArray


def visualize_temperature(
    temperature: NDArray[np.float64],
    x_length: float,
    y_length: float,
    residual: float,
) -> None:
    """Display the computed temperature field."""

    figure, axis = plt.subplots(figsize=(7, 5))
    image = axis.imshow(
        temperature,
        origin="lower",
        vmin=0.0,
        vmax=float(np.max(temperature)),
        aspect="equal",
        extent=[0.0, x_length, 0.0, y_length],
        cmap="hot",
    )
    figure.colorbar(image, ax=axis, label="Temperature")
    axis.set_xlabel("x")
    axis.set_ylabel("y")
    axis.set_title(f"Poisson temperature field (relative residual: {residual:.2e})")
    figure.tight_layout()
    plt.show()
