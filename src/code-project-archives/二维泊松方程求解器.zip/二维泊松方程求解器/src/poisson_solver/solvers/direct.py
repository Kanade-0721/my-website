import numpy as np
from numpy.typing import NDArray
from scipy.sparse import csr_matrix, lil_matrix
from scipy.sparse.linalg import spsolve

from ..residual import relative_residual


def assemble_poisson_system(
    source: NDArray[np.float64],
    nx: int,
    ny: int,
    dx: float,
    dy: float,
) -> tuple[csr_matrix, NDArray[np.float64]]:
    """Assemble the five-point finite-difference system for ``-laplace(T)=q``."""

    if source.shape != (ny, nx):
        raise ValueError(f"source must have shape {(ny, nx)}, got {source.shape}.")
    if nx < 3 or ny < 3:
        raise ValueError("Each grid direction must contain at least 3 points.")
    if dx <= 0 or dy <= 0:
        raise ValueError("Grid spacing must be positive.")

    nx_inner = nx - 2
    ny_inner = ny - 2
    unknown_count = nx_inner * ny_inner
    matrix = lil_matrix((unknown_count, unknown_count), dtype=float)

    center_coefficient = 2.0 / dx**2 + 2.0 / dy**2
    x_coefficient = -1.0 / dx**2
    y_coefficient = -1.0 / dy**2

    # Flattening order: p = j * nx_inner + i, so p +/- 1 moves in x.
    for p in range(unknown_count):
        matrix[p, p] = center_coefficient

        if p % nx_inner != 0:
            matrix[p, p - 1] = x_coefficient
        if p % nx_inner != nx_inner - 1:
            matrix[p, p + 1] = x_coefficient
        if p // nx_inner != 0:
            matrix[p, p - nx_inner] = y_coefficient
        if p // nx_inner != ny_inner - 1:
            matrix[p, p + nx_inner] = y_coefficient

    right_hand_side = source[1:-1, 1:-1].ravel().copy()
    return matrix.tocsr(), right_hand_side


def solve_direct(
    source: NDArray[np.float64],
    dx: float,
    dy: float,
) -> tuple[NDArray[np.float64], float]:
    """Solve the zero-Dirichlet Poisson problem with SciPy's sparse solver."""

    ny, nx = source.shape
    matrix, right_hand_side = assemble_poisson_system(source, nx, ny, dx, dy)
    inner_solution = np.asarray(spsolve(matrix, right_hand_side))

    temperature = np.zeros((ny, nx), dtype=float)
    temperature[1:-1, 1:-1] = inner_solution.reshape((ny - 2, nx - 2))
    residual = relative_residual(matrix, inner_solution, right_hand_side)
    return temperature, residual
