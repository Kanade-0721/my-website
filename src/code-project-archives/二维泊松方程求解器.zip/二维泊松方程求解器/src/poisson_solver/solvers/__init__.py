"""Linear solvers for the discretized Poisson equation."""

from .direct import assemble_poisson_system, solve_direct

__all__ = ["assemble_poisson_system", "solve_direct"]
