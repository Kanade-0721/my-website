from .config import SimulationConfig
from .mesh import create_mesh
from .solvers.direct import solve_direct
from .source import gaussian_source
from .visualization import visualize_temperature


def main() -> None:
    """Run the default two-dimensional Poisson example."""

    config = SimulationConfig()
    x_grid, y_grid, dx, dy = create_mesh(
        config.x_length,
        config.y_length,
        config.nx,
        config.ny,
    )
    source = gaussian_source(
        x_grid,
        y_grid,
        x_center=config.x_length / 2.0,
        y_center=config.y_length / 2.0,
        sigma=config.source_sigma,
        amplitude=config.source_amplitude,
    )
    temperature, residual = solve_direct(source, dx, dy)

    print(f"Center temperature: {temperature[config.ny // 2, config.nx // 2]:.6f}")
    print(f"Relative residual: {residual:.3e}")
    visualize_temperature(
        temperature,
        config.x_length,
        config.y_length,
        residual,
    )
