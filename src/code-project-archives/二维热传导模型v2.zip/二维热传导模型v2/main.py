from heat2d.app import main


if __name__ == "__main__":
    main()
