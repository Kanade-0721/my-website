import numpy as np

from .boundary import boundary


def initial_temperature(sigma, X, Y):
    x_center = (X.min() + X.max()) / 2
    y_center = (Y.min() + Y.max()) / 2
    temperature = 20 + 80 * np.exp(
        -(
            (X - x_center) ** 2
            + (Y - y_center) ** 2
        )
        / (2 * sigma**2)
    )

    boundary(temperature)

    return temperature
