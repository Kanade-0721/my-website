import numpy as np


def create_grid(
    x_length,
    nx,
    y_length,
    ny,
    alpha,
):
    x = np.linspace(0, x_length, nx)
    y = np.linspace(0, y_length, ny)

    dx = x[1] - x[0]
    dy = y[1] - y[0]

    dt_limit = 1.0 / (
        2.0
        * alpha
        * (
            1.0 / dx**2
            + 1.0 / dy**2
        )
    )

    dt = 0.8 * dt_limit

    X, Y = np.meshgrid(x, y)

    return X, Y, dx, dy, dt
