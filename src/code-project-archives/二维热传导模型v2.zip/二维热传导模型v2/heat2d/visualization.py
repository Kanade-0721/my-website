import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation


def plot_temperature_animation(
    temperature_history,
    times,
    x_length,
    y_length,
):
    fig, ax = plt.subplots(figsize=(7, 6))

    current_temperature = temperature_history[0]

    image = ax.imshow(
        current_temperature,
        origin="lower",
        extent=[0.0, x_length, 0.0, y_length],
        vmin=20.0,
        vmax=100.0,
    )

    fig.colorbar(
        image,
        ax=ax,
        label="Temperature(°C)",
    )

    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_aspect("equal")

    title = ax.set_title(
        f"Temperature Field, t = {times[0]:.2f} s"
    )

    def update(frame):
        time = times[frame]
        new_temperature = temperature_history[frame]
        image.set_data(new_temperature)
        title.set_text(
            f"Temperature Field, t = {time:.2f} s"
        )
        return image, title

    animation = FuncAnimation(
        fig,
        update,
        frames=len(times),
        interval=50,
        repeat=True,
        repeat_delay=1000,
    )

    plt.show()
    return animation
