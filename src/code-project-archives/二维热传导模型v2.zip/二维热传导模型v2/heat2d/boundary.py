import numpy as np


def boundary(T: np):
    T[:, 0] = 20
    T[:, -1] = 20
    T[0, :] = 20
    T[-1, :] = 20

    return T
