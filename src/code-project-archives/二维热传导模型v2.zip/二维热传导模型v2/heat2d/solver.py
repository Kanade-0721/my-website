from .boundary import boundary


def solve(
    T,
    times,
    alpha,
    dt,
    dx,
    dy,
):
    temperature = []
    temperature.append(T.copy())

    current_time = 0.0

    for i in range(1, len(times)):
        target_time = times[i]

        while current_time < target_time:
            current_dt = min(
                dt,
                target_time - current_time,
            )

            rx = alpha * current_dt / dx**2
            ry = alpha * current_dt / dy**2

            if rx + ry > 0.5:
                raise ValueError("时间步不满足显式差分稳定性条件")

            T_new = T.copy()

            T_new[1:-1, 1:-1] = (
                T[1:-1, 1:-1]
                + rx
                * (
                    T[1:-1, 2:]
                    - 2 * T[1:-1, 1:-1]
                    + T[1:-1, :-2]
                )
                + ry
                * (
                    T[2:, 1:-1]
                    - 2 * T[1:-1, 1:-1]
                    + T[:-2, 1:-1]
                )
            )

            boundary(T_new)

            T = T_new
            current_time += current_dt

        temperature.append(T.copy())

    return temperature
