import numpy as np

from .config import set_config
from .grid import create_grid
from .initial_conditions import initial_temperature
from .solver import solve
from .visualization import plot_temperature_animation


def main():
    config = set_config()
    times = np.linspace(0, config.time, config.frames)

    print("本次模拟的参数为：")
    print(config)

    X, Y, dx, dy, dt = create_grid(
        config.x_length,
        config.nx,
        config.y_length,
        config.ny,
        config.alpha,
    )

    temperature = initial_temperature(config.sigma, X, Y)

    temperature_history = solve(
        temperature,
        times,
        config.alpha,
        dt,
        dx,
        dy,
    )

    plot_temperature_animation(
        temperature_history,
        times,
        config.x_length,
        config.y_length,
    )
