"""二维热传导数值模拟包。"""

from .config import SimulationConfig
from .solver import solve

__all__ = ["SimulationConfig", "solve"]
